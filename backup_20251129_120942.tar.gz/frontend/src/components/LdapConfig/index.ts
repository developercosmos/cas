export { default } from './LdapConfig';
