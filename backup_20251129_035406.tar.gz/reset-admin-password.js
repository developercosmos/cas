#!/usr/bin/env node

/**
 * Admin Password Reset Utility
 * Usage: node reset-admin-password.js [new-password]
 * Default password: admin
 */

const pg = require('pg');

async function resetAdminPassword(newPassword = 'admin') {
  const databaseUrl = 'postgresql://dashboard_user:dashboard_password@localhost:5432/dashboard_db';
  const pool = new pg.Pool({ connectionString: databaseUrl });

  try {
    console.log('🔧 Connecting to database...');
    const client = await pool.connect();

    // Generate new password hash
    const bcrypt = require('bcryptjs');
    const saltRounds = 10;
    const passwordHash = await bcrypt.hash(newPassword, saltRounds);

    console.log('🔄 Updating admin password...');
    const result = await client.query(
      'UPDATE auth.users SET PasswordHash = $1, UpdatedAt = NOW() WHERE Username = $2',
      [passwordHash, 'admin']
    );

    if (result.rowCount === 0) {
      console.log('❌ Admin user not found in database');
      return;
    }

    console.log('✅ Password update completed!');
    console.log('Rows affected:', result.rowCount);

    // Verify the update
    const verifyResult = await client.query(
      'SELECT Username, Email, UpdatedAt FROM auth.users WHERE Username = $1',
      ['admin']
    );

    if (verifyResult.rows.length > 0) {
      console.log('✅ Admin user verified:', verifyResult.rows[0]);
      console.log('🔑 Password has been reset to:', newPassword);
      console.log('🌐 Login credentials:');
      console.log('   Username: admin');
      console.log('   Password:', newPassword);
      console.log('   Last updated:', verifyResult.rows[0].updatedat);
    } else {
      console.log('❌ Admin user verification failed');
    }

    client.release();

  } catch (error) {
    console.error('❌ Error resetting password:', error.message);

    if (error.code === 'ECONNREFUSED') {
      console.log('💡 Make sure PostgreSQL is running: sudo systemctl start postgresql');
    } else if (error.code === '3D000') {
      console.log('💡 Database does not exist. Make sure the database is created.');
    } else if (error.code === '28P01') {
      console.log('💡 Authentication failed. Check database credentials in .env file.');
    }

    process.exit(1);
  } finally {
    await pool.end();
  }
}

// Command line argument handling
const args = process.argv.slice(2);
const newPassword = args[0] || 'admin';

console.log('🚀 Starting admin password reset...');
console.log('New password will be:', newPassword);
console.log('');

resetAdminPassword(newPassword).then(() => {
  console.log('');
  console.log('🎉 Password reset completed successfully!');
  console.log('💡 You can now login to the CAS application');
}).catch((error) => {
  console.error('💥 Password reset failed:', error.message);
  process.exit(1);
});